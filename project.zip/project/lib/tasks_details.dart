import 'package:flutter/material.dart';

class TaskDetailsScreen extends StatelessWidget {
  final String task;

  TaskDetailsScreen({required this.task});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task Details'),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text(
            task,
            style: TextStyle(fontSize: 24),
          ),
        ),
      ),
    );
  }
}